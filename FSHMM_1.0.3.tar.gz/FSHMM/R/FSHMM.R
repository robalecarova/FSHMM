#' @title Feature Selection Hidden Markov Model
#'
#'@description
#' A feature selection algorithm taht selects the best variables of the observation matrix.
#' FSHMM allows the user to select the most relevant features of one or 
#' multiple conditions experiments by using a hidden Markov model. 
#' This strategy can summarize the biological replicates
#' to get a customized model. Also, the user can provide \emph{a priori} information
#' to the model to make a faster convergence based in biological data. The HMM is used 
#' to model the time dependency and its states
#' represent "Change" or "No Change", this state structure helps to filter the variables
#' that does not change in time. The model estimates its parameters from the data by using
#' an Expectation-Maximization algorithm, this approach is useful to get ad-hoc Change thresholds 
#' for the studied data. In the multiple condition feature selection strategy, the variables selected
#' depends on the Control/Baseline condition.
#' 
#' @references 
#' \itemize{
#' \item  Bilmes, J.E. (1998). A Gentle Tutorial of the EM Algorithm and its Application to Parameter Estimation for Gaussian Mixture and Hidden Markov Models. \emph{International Computer Science Institute}.
#' \item Ibe, O. (2009). Markov processes for stochastic modeling. \emph{Oxford}.
#' \item Rabiner, L.R. (1989). A tutorial on hidden Markov models and selected applications in speech recognition. \emph{Proceedings of the IEEE}.
#' \item Adams, S and Beling, P. (2017) A survey of feature selection methods for Gaussian mixture models and hidden Markov models, \emph{ Artif Intell Rev.}, doi:10.1007/s10462-017-9581-3.
#' \item Saeys, Y et al. (2007) A review of feature selection techniques in bioinformatics, \emph{ Bioinformatics.},  23, 2507-2517.
#' }
#' @author Roberto A. Cardenas-Ovando, \email{robalecarova@@gmail.com}, Hector A. Rueda-Zarate, Julieta Noguez, Claudia Rangel-Escareno
"_PACKAGE"
#> [1] "_PACKAGE"